# -*- coding: utf-8 -*-
import scrapy
from ..items import AmazonItem

class AmazonspiderSpider(scrapy.Spider):
    name = 'amazonspider'
    start_urls = ['https://www.amazon.com/s?k=core+i7+laptop&i=electronics&rh=n%3A172282%2Cp_72%3A2661619011&dc&crid=1H2D5U77EOIZH&qid=1557137997&rnid=2257851011&sprefix=core+i7+la%2Caps%2C300&ref=sr_nr_p_n_feature_five_browse-bin_1']
    page_number=2

    def parse(self, response):
    	items=AmazonItem()

    	product_name=response.css('.a-color-base.a-text-normal').css('::text').extract()
    	product_price=response.css('.a-price-whole').css('::text').extract()
    	product_url=response.css('h2 a.a-link-normal.a-text-normal').css('::attr(href)').extract()
    	product_image=response.css('.s-image').css('::attr(src)').extract()
    	
    	items['product_name']=product_name
    	items['product_price']=product_price
    	items['product_url']=product_url
    	items['product_image']=product_image

    	yield items
    	
    	next_page='https://www.amazon.com/s?k=core+i7+laptop&i=electronics&rh=n%3A172282%2Cp_72%3A2661619011&dc&page='+str(AmazonspiderSpider.page_number)+'&crid=1H2D5U77EOIZH&qid=1557138013&rnid=2257851011&sprefix=core+i7+la%2Caps%2C300&ref=sr_pg_2'
    	if AmazonspiderSpider.page_number <= 100:
    		AmazonspiderSpider.page_number+=1
    		yield response.follow(next_page,callback=self.parse)